package com.fatec.ProjetoSpringTeste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSpringTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSpringTesteApplication.class, args);
	}

}
